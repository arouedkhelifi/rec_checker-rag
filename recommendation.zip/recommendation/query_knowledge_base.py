#!/usr/bin/env python3
"""
Knowledge Base Query Tool

A utility to query the FAISS vector index and retrieve relevant recommendations
based on semantic similarity to the input query. This tool is useful for:
1. Debugging the vector database
2. Testing retrieval quality
3. Quick access to recommendations without the full RAG pipeline
4. Evaluating different query formulations

Usage:
    python query_knowledge_base.py [--query "your query here"]
    python query_knowledge_base.py --interactive
"""

import json
import sys
import argparse
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

# Vector search libraries
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from rich.console import Console
from rich.table import Table
from rich.markdown import Markdown
from rich.panel import Panel

# Default configuration
DEFAULT_MODEL = "all-MiniLM-L6-v2"
DEFAULT_INDEX_PATH = "knowledge_base.index"
DEFAULT_METADATA_PATH = "knowledge_base_metadata.json"
DEFAULT_TOP_K = 5

# Initialize rich console
console = Console()

def load_resources(index_path: str, metadata_path: str, model_name: str):
    """
    Load the FAISS index, metadata, and embedding model.
    
    Args:
        index_path: Path to the FAISS index file
        metadata_path: Path to the metadata JSON file
        model_name: Name of the sentence transformer model
        
    Returns:
        Tuple of (index, metadata, model)
    """
    try:
        # Load the FAISS index
        with console.status(f"Loading index from {index_path}..."):
            index = faiss.read_index(index_path)
            console.print(f"✅ Loaded index with [bold]{index.ntotal}[/bold] vectors")
        
        # Load the metadata
        with console.status(f"Loading metadata from {metadata_path}..."):
            with open(metadata_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                
            # Handle both formats (list or dict with chunks key)
            if isinstance(data, dict) and "chunks" in data:
                metadatas = data["chunks"]
                # Print metadata info if available
                if "metadata" in data:
                    console.print(f"📊 Knowledge base info:")
                    for key, value in data["metadata"].items():
                        if key != "sections":
                            console.print(f"   [bold]{key}[/bold]: {value}")
            else:
                metadatas = data
                
            console.print(f"✅ Loaded [bold]{len(metadatas)}[/bold] metadata entries")
        
        # Load the embedding model
        with console.status(f"Loading embedding model: {model_name}"):
            model = SentenceTransformer(model_name)
            console.print(f"✅ Model loaded successfully")
            
        return index, metadatas, model
        
    except Exception as e:
        console.print(f"[bold red]Error loading resources:[/bold red] {str(e)}")
        raise

def query_knowledge_base(
    index: faiss.Index, 
    metadatas: List[Dict[str, Any]], 
    query: str, 
    top_k: int = 5, 
    model: Optional[SentenceTransformer] = None,
    threshold: float = 1.5
) -> List[Dict[str, Any]]:
    """
    Query the FAISS index with input text.
    
    Args:
        index: FAISS index object
        metadatas: List of metadata dictionaries
        query: Query text
        top_k: Number of top results to return
        model: Optional pre-loaded SentenceTransformer model
        threshold: Maximum distance threshold for results
        
    Returns:
        A list of top_k matched metadata entries
    """
    # Use provided model or load the default one
    if model is None:
        model = SentenceTransformer(DEFAULT_MODEL)
    
    # Generate embedding for the query text
    start_time = time.time()
    query_vector = model.encode(query).astype("float32")
    encoding_time = time.time() - start_time
    
    # Search the index for similar vectors
    start_time = time.time()
    distances, indices = index.search(np.array([query_vector]), top_k * 2)  # Get more results for filtering
    search_time = time.time() - start_time
    
    # Collect and return the matching metadata
    results = []
    for i, idx in enumerate(indices[0]):
        if idx >= 0 and idx < len(metadatas):  # Ensure index is valid
            distance = float(distances[0][i])
            
            # Filter by threshold
            if distance > threshold:
                continue
                
            result = metadatas[idx].copy()
            # Add distance score and search metadata
            result["score"] = 1.0 / (1.0 + distance)  # Convert distance to similarity score (0-1)
            result["distance"] = distance
            result["rank"] = i + 1
            results.append(result)
    
    # Add timing information to the first result if available
    if results:
        results[0]["_encoding_time"] = encoding_time
        results[0]["_search_time"] = search_time
    
    return results[:top_k]  # Return at most top_k results

def display_results(results: List[Dict[str, Any]], query: str):
    """
    Display query results in a nicely formatted table.
    
    Args:
        results: List of result dictionaries
        query: The original query
    """
    if not results:
        console.print(Panel("[bold yellow]No results found matching your query.[/bold yellow]", 
                           title="Search Results"))
        return
        
    # Display query and timing info
    console.print(f"\n[bold]Query:[/bold] {query}")
    if "_encoding_time" in results[0] and "_search_time" in results[0]:
        encoding_time = results[0]["_encoding_time"]
        search_time = results[0]["_search_time"]
        console.print(f"[dim]Encoding: {encoding_time:.4f}s, Search: {search_time:.4f}s, " +
                     f"Total: {encoding_time + search_time:.4f}s[/dim]")
    
    # Create results table
    table = Table(title=f"Top {len(results)} Results")
    table.add_column("Rank", style="dim")
    table.add_column("Score", style="green")
    table.add_column("Section", style="blue")
    table.add_column("Text", style="white", no_wrap=False)
    
    # Add rows to table
    for result in results:
        score = result.get("score", 0)
        score_str = f"{score:.2f}"
        
        # Format text to avoid overly long lines
        text = result.get("text", "")
        if len(text) > 100:
            text = text[:97] + "..."
            
        table.add_row(
            str(result.get("rank", "-")),
            score_str,
            result.get("section", "Unknown"),
            text
        )
    
    console.print(table)
    
    # Display full text of top result
    if results:
        top_result = results[0]
        console.print("\n[bold]Top Result Details:[/bold]")
        console.print(f"[bold blue]Section:[/bold blue] {top_result.get('section', 'Unknown')}")
        console.print(f"[bold green]Score:[/bold green] {top_result.get('score', 0):.4f}")
        
        # Display keywords if available
        if "keywords" in top_result:
            keywords = ", ".join(top_result["keywords"])
            console.print(f"[bold yellow]Keywords:[/bold yellow] {keywords}")
            
        console.print("\n[bold]Text:[/bold]")
        console.print(Panel(top_result.get("text", ""), width=100))

def interactive_mode(index, metadatas, model):
    """
    Run an interactive query session.
    
    Args:
        index: FAISS index
        metadatas: Metadata list
        model: SentenceTransformer model
    """
    console.print(Panel.fit(
        "[bold]Interactive Query Mode[/bold]\n"
        "Enter your queries below. Type 'exit', 'quit', or press Ctrl+C to exit.",
        title="Knowledge Base Explorer"
    ))
    
    try:
        while True:
            query = console.input("\n[bold green]Enter query:[/bold green] ")
            if query.lower() in ("exit", "quit", "q"):
                break
                
            if not query.strip():
                continue
                
            with console.status("[bold green]Searching...[/bold green]"):
                results = query_knowledge_base(index, metadatas, query, model=model)
                
            display_results(results, query)
            
    except KeyboardInterrupt:
        console.print("\n[bold]Exiting interactive mode[/bold]")

def main():
    """Main function to handle command line arguments and run the query."""
    parser = argparse.ArgumentParser(
        description='Query the knowledge base for relevant recommendations'
    )
    parser.add_argument(
        '--index', '-i',
        default=DEFAULT_INDEX_PATH,
        help='Path to FAISS index file'
    )
    parser.add_argument(
        '--metadata', '-m',
        default=DEFAULT_METADATA_PATH,
        help='Path to metadata JSON file'
    )
    parser.add_argument(
        '--model', '-e',
        default=DEFAULT_MODEL,
        help='Sentence transformer model name'
    )
    parser.add_argument(
        '--top-k', '-k',
        type=int,
        default=DEFAULT_TOP_K,
        help='Number of top results to return'
    )
    parser.add_argument(
        '--threshold', '-t',
        type=float,
        default=1.5,
        help='Maximum distance threshold for results'
    )
    parser.add_argument(
        '--query', '-q',
        help='Query text (if not provided, will prompt for input)'
    )
    parser.add_argument(
        '--interactive', '-I',
        action='store_true',
        help='Run in interactive mode'
    )
    
    args = parser.parse_args()
    
    try:
        # Load resources
        index, metadatas, model = load_resources(args.index, args.metadata, args.model)
        
        # Run in interactive mode if requested
        if args.interactive:
            interactive_mode(index, metadatas, model)
            return 0
        
        # Get query text from argument or prompt
        query_text = args.query
        if not query_text:
            query_text = console.input("[bold green]Enter your query:[/bold green] ")
        
        # Query the knowledge base
        with console.status("[bold green]Searching...[/bold green]"):
            results = query_knowledge_base(
                index, metadatas, query_text, 
                top_k=args.top_k, model=model,
                threshold=args.threshold
            )
        
        # Display results
        display_results(results, query_text)
        
        return 0
    except FileNotFoundError as e:
        console.print(f"[bold red]Error: File not found[/bold red] - {e}")
        return 1
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        return 1

if __name__ == "__main__":
    exit(main())
