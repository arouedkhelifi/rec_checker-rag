#!/usr/bin/env python3
"""
Vector Store Builder

This script builds a FAISS vector index from knowledge chunks for the RAG
(Retrieval-Augmented Generation) pipeline. It embeds text chunks using a
sentence transformer model and creates a searchable vector database.

Enhanced features:
- Batch processing for faster embedding
- Multiple index types (Flat, IVF, HNSW)
- Index training for better performance
- Embedding caching to avoid recomputing
- Progress tracking with ETA
- Detailed quality metrics

Usage:
    python build_vector_store.py [--input INPUT_FILE] [--index-output INDEX_FILE] 
                                [--metadata-output METADATA_FILE] [--model MODEL_NAME]
                                [--index-type {flat,ivf,hnsw}] [--batch-size BATCH_SIZE]
                                [--cache-embeddings]
"""

import json
import logging
import argparse
import os
import time
import hashlib
import pickle
from pathlib import Path
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime

import numpy as np
import faiss
from tqdm import tqdm
from sentence_transformers import SentenceTransformer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Default model for sentence embeddings
DEFAULT_MODEL = "all-MiniLM-L6-v2"
# Alternative models to consider:
# - "all-mpnet-base-v2" (higher quality, slower)
# - "multi-qa-mpnet-base-dot-v1" (optimized for retrieval)
# - "paraphrase-multilingual-mpnet-base-v2" (multilingual support)

# Default batch size for embedding
DEFAULT_BATCH_SIZE = 32

# Cache directory for embeddings
CACHE_DIR = ".embedding_cache"

def get_text_hash(text: str) -> str:
    """
    Generate a hash for text to use as a cache key.
    
    Args:
        text: The text to hash
        
    Returns:
        Hash string
    """
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def get_embeddings_batch(
    texts: List[str], 
    model: SentenceTransformer,
    batch_size: int = DEFAULT_BATCH_SIZE,
    use_cache: bool = False
) -> np.ndarray:
    """
    Generate embedding vectors for a batch of texts.
    
    Args:
        texts: List of texts to embed
        model: The sentence transformer model to use
        batch_size: Number of texts to process at once
        use_cache: Whether to use embedding cache
        
    Returns:
        Numpy array of embeddings
    """
    embeddings = []
    texts_to_embed = []
    cache_keys = []
    cache_indices = []
    
    # Create cache directory if it doesn't exist
    if use_cache and not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)
    
    # Check cache for existing embeddings
    if use_cache:
        for i, text in enumerate(texts):
            text_hash = get_text_hash(text)
            cache_path = os.path.join(CACHE_DIR, f"{text_hash}.pkl")
            
            if os.path.exists(cache_path):
                try:
                    with open(cache_path, 'rb') as f:
                        embedding = pickle.load(f)
                    embeddings.append((i, embedding))
                except Exception as e:
                    logger.debug(f"Cache error for {text_hash}: {e}")
                    texts_to_embed.append(text)
                    cache_keys.append(text_hash)
                    cache_indices.append(i)
            else:
                texts_to_embed.append(text)
                cache_keys.append(text_hash)
                cache_indices.append(i)
    else:
        texts_to_embed = texts
        cache_indices = list(range(len(texts)))
    
    # If all embeddings were cached, return them
    if not texts_to_embed:
        # Sort by original index and extract just the embeddings
        embeddings.sort(key=lambda x: x[0])
        return np.array([emb for _, emb in embeddings])
    
    # Process in batches
    batch_embeddings = []
    for i in range(0, len(texts_to_embed), batch_size):
        batch_texts = texts_to_embed[i:i+batch_size]
        batch = model.encode(batch_texts, show_progress_bar=False)
        batch_embeddings.extend(batch)
        
        # Cache embeddings
        if use_cache:
            for j, embedding in enumerate(batch):
                idx = i + j
                if idx < len(cache_keys):
                    cache_path = os.path.join(CACHE_DIR, f"{cache_keys[idx]}.pkl")
                    try:
                        with open(cache_path, 'wb') as f:
                            pickle.dump(embedding, f)
                    except Exception as e:
                        logger.debug(f"Failed to cache embedding: {e}")
    
    # Combine cached and new embeddings
    if use_cache:
        # Add new embeddings
        for i, embedding in zip(cache_indices, batch_embeddings):
            embeddings.append((i, embedding))
        
        # Sort by original index and extract just the embeddings
        embeddings.sort(key=lambda x: x[0])
        return np.array([emb for _, emb in embeddings])
    else:
        return np.array(batch_embeddings)

def create_faiss_index(vectors: np.ndarray, index_type: str = "flat") -> faiss.Index:
    """
    Create a FAISS index of the specified type.
    
    Args:
        vectors: Numpy array of vectors to index
        index_type: Type of index to create (flat, ivf, hnsw)
        
    Returns:
        FAISS index
    """
    dimension = vectors.shape[1]
    
    if index_type == "flat":
        # Simple flat index - exact but slower for large datasets
        index = faiss.IndexFlatL2(dimension)
        index.add(vectors)
        return index
        
    elif index_type == "ivf":
        # IVF index - faster search with slight accuracy tradeoff
        # Number of centroids - rule of thumb: sqrt(n) where n is dataset size
        nlist = int(np.sqrt(vectors.shape[0]))
        nlist = max(1, min(nlist, 2048))  # Keep reasonable bounds
        
        quantizer = faiss.IndexFlatL2(dimension)
        index = faiss.IndexIVFFlat(quantizer, dimension, nlist)
        
        # Train the index
        logger.info(f"Training IVF index with {nlist} clusters...")
        index.train(vectors)
        
        # Add vectors
        index.add(vectors)
        
        # Set number of probes for search (higher = more accurate but slower)
        index.nprobe = min(20, nlist)
        
        return index
        
    elif index_type == "hnsw":
        # HNSW index - very fast with good accuracy
        M = 16  # Number of connections per layer (default: 16)
        ef_construction = 200  # Size of the dynamic list for constructing the graph (default: 40)
        
        index = faiss.IndexHNSWFlat(dimension, M)
        index.hnsw.efConstruction = ef_construction
        index.add(vectors)
        
        # Set search parameters
        index.hnsw.efSearch = 128  # Size of the dynamic list for searching (default: 16)
        
        return index
        
    else:
        raise ValueError(f"Unknown index type: {index_type}")

def build_vector_store(
    knowledge_chunks: List[Dict[str, Any]], 
    model_name: str = DEFAULT_MODEL,
    index_type: str = "flat",
    batch_size: int = DEFAULT_BATCH_SIZE,
    use_cache: bool = False,
    save_files: bool = False,
    index_path: Optional[str] = None,
    metadata_path: Optional[str] = None
) -> Tuple[faiss.Index, List[Dict[str, Any]]]:
    """
    Build a FAISS index and metadata list from knowledge chunks.
    
    Args:
        knowledge_chunks: List of dictionaries containing section and text
        model_name: Name of the sentence transformer model to use
        index_type: Type of FAISS index to create (flat, ivf, hnsw)
        batch_size: Batch size for embedding generation
        use_cache: Whether to cache embeddings to disk
        save_files: Whether to save the index and metadata to disk
        index_path: Path to save the FAISS index (if save_files is True)
        metadata_path: Path to save the metadata (if save_files is True)
        
    Returns:
        Tuple containing (faiss_index, metadata_list)
    """
    # Extract chunks from the input format if needed
    if "chunks" in knowledge_chunks and isinstance(knowledge_chunks["chunks"], list):
        chunks = knowledge_chunks["chunks"]
    elif isinstance(knowledge_chunks, list):
        chunks = knowledge_chunks
    else:
        raise ValueError("Invalid knowledge chunks format")
    
    # Load the embedding model
    logger.info(f"Loading sentence transformer model: {model_name}")
    start_time = time.time()
    try:
        model = SentenceTransformer(model_name)
    except Exception as e:
        logger.error(f"Failed to load model {model_name}: {e}")
        raise
    logger.info(f"Model loaded in {time.time() - start_time:.2f} seconds")
    
    # Prepare texts and metadata
    texts = []
    metadatas = []
    
    logger.info(f"Processing {len(chunks)} chunks for vector embedding")
    
    # Extract texts and metadata
    for chunk in chunks:
        if "text" in chunk and chunk["text"].strip():
            texts.append(chunk["text"])
            metadatas.append(chunk)
    
    # Generate embeddings in batches
    logger.info(f"Generating embeddings with batch size {batch_size}")
    start_time = time.time()
    try:
        vectors = get_embeddings_batch(texts, model, batch_size, use_cache)
        embedding_time = time.time() - start_time
        logger.info(f"Generated {len(vectors)} embeddings in {embedding_time:.2f} seconds " +
                   f"({len(vectors) / embedding_time:.2f} embeddings/second)")
    except Exception as e:
        logger.error(f"Failed to generate embeddings: {e}")
        raise
    
    # Create and populate the FAISS index
    logger.info(f"Building {index_type.upper()} FAISS index with {len(vectors)} vectors of dimension {vectors.shape[1]}")
    start_time = time.time()
    try:
        index = create_faiss_index(vectors, index_type)
        logger.info(f"FAISS index built in {time.time() - start_time:.2f} seconds")
    except Exception as e:
        logger.error(f"Failed to build FAISS index: {e}")
        raise
    
    # Save files if requested
    if save_files:
        if not index_path:
            index_path = f"knowledge_base_{index_type}.index"
        if not metadata_path:
            metadata_path = "knowledge_base_metadata.json"
            
        try:
            logger.info(f"Saving FAISS index to: {index_path}")
            faiss.write_index(index, index_path)
            
            # Create metadata with additional info
            metadata_with_info = {
                "metadata": {
                    "created_at": datetime.now().isoformat(),
                    "model": model_name,
                    "index_type": index_type,
                    "vector_count": len(vectors),
                    "vector_dimension": vectors.shape[1],
                    "version": "2.0"
                },
                "chunks": metadatas
            }
            
            logger.info(f"Saving metadata to: {metadata_path}")
            with open(metadata_path, "w", encoding="utf-8") as f:
                json.dump(metadata_with_info, f, indent=2, ensure_ascii=False)
                
            logger.info("✅ Knowledge base built and saved successfully")
        except Exception as e:
            logger.error(f"Failed to save files: {e}")
            raise
    
    return index, metadatas

def main():
    """Main function to parse arguments and run the vector store building process."""
    parser = argparse.ArgumentParser(
        description='Build vector store for RAG processing'
    )
    parser.add_argument(
        '--input', '-i',
        default="knowledge_chunks.json",
        help='Path to knowledge chunks JSON file'
    )
    parser.add_argument(
        '--index-output',
        help='Output path for FAISS index'
    )
    parser.add_argument(
        '--metadata-output',
        help='Output path for metadata JSON'
    )
    parser.add_argument(
        '--model', '-m',
        default=DEFAULT_MODEL,
        help='Sentence transformer model name'
    )
    parser.add_argument(
        '--index-type', '-t',
        choices=['flat', 'ivf', 'hnsw'],
        default='flat',
        help='Type of FAISS index to create'
    )
    parser.add_argument(
        '--batch-size', '-b',
        type=int,
        default=DEFAULT_BATCH_SIZE,
        help='Batch size for embedding generation'
    )
    parser.add_argument(
        '--cache-embeddings', '-c',
        action='store_true',
        help='Cache embeddings to disk for faster reuse'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    # Set debug logging if requested
    if args.debug:
        logger.setLevel(logging.DEBUG)
    
    # Determine output paths if not specified
    index_path = args.index_output
    if not index_path:
        index_path = f"knowledge_base_{args.index_type}.index"
        
    metadata_path = args.metadata_output
    if not metadata_path:
        metadata_path = "knowledge_base_metadata.json"
    
    try:
        # Load knowledge chunks
        logger.info(f"Loading knowledge chunks from: {args.input}")
        with open(args.input, "r", encoding="utf-8") as f:
            knowledge_chunks = json.load(f)
        
        # Build vector store
        index, metadatas = build_vector_store(
            knowledge_chunks, 
            model_name=args.model,
            index_type=args.index_type,
            batch_size=args.batch_size,
            use_cache=args.cache_embeddings,
            save_files=True,
            index_path=index_path,
            metadata_path=metadata_path
        )
        
        logger.info(f"Vector store built successfully with {len(metadatas)} items")
        return 0
    except Exception as e:
        logger.error(f"Vector store building failed: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 1

if __name__ == "__main__":
    exit(main())
