"""
Recommendation Checker Chatbot - RAG Generation Interface

This script implements a RAG system with a Gradio web interface.
You can upload a code file, and it will check if the code complies
with the recommendations extracted from the document.
"""
from utils import prepare_state_from_input
import os # to interact with the os and handle files directories and environment variables in a secure way 
import json #for reading and writinf json files and strings
import sys # let my script read command-line arguments, handle exits, and interact with the Python runtime
import argparse
import time
import hashlib
import re
import logging
import concurrent.futures
from typing import TypedDict, List, Dict, Any, Optional, Tuple
from datetime import datetime
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import litellm
from litellm import completion
from langgraph.graph import StateGraph, END
import gradio as gr
from tenacity import retry, stop_after_attempt, wait_exponential

# === Configuration ===
DEFAULT_MODEL = "all-MiniLM-L6-v2"
DEFAULT_LLM = "vertex_ai/gemini-2.5-flash"
DEFAULT_INDEX_PATH = "knowledge_base_flat.index"
DEFAULT_METADATA_PATH = "knowledge_base_metadata.json"
DEFAULT_CREDENTIALS_PATH = "vertex_service_key.json"

DEFAULT_VERTEX_PROJECT = "sbx-31371-xqb8wl8nfq92oxlg54th"
DEFAULT_VERTEX_LOCATION = "us-central1"

RESPONSE_CACHE = {}
MAX_CACHE_SIZE = 50
MAX_CHUNK_SIZE = 5000  # Maximum size for code chunks

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s')
logger = logging.getLogger(__name__)

LANGUAGE_PATTERNS = {
    "python": [r'\.py$', r'import\s+', r'from\s+\w+\s+import', r'def\s+\w+\s*\(', r'class\s+\w+\s*:'],
    "javascript": [r'\.js$', r'const\s+', r'let\s+', r'var\s+', r'function\s+', r'import\s+.*from', r'export\s+'],
    "java": [r'\.java$', r'public\s+class', r'private\s+', r'protected\s+', r'import\s+java\.', r'package\s+'],
    "typescript": [r'\.ts$', r'interface\s+', r'type\s+', r'namespace\s+', r'enum\s+'],
    "go": [r'\.go$', r'package\s+main', r'func\s+', r'import\s+\(', r'type\s+\w+\s+struct'],
    "rust": [r'\.rs$', r'fn\s+main', r'let\s+mut', r'use\s+std', r'impl\s+', r'pub\s+fn'],
    "c#": [r'\.cs$', r'namespace\s+', r'using\s+System', r'public\s+class', r'private\s+void'],
    "php": [r'\.php$', r'\<\?php', r'function\s+', r'namespace\s+', r'use\s+'],
    "ruby": [r'\.rb$', r'require\s+', r'def\s+', r'class\s+', r'module\s+'],
    "swift": [r'\.swift$', r'import\s+Foundation', r'func\s+', r'class\s+', r'struct\s+'],
    "kotlin": [r'\.kt$', r'fun\s+main', r'val\s+', r'var\s+', r'class\s+', r'package\s+'],
    "c++": [r'\.cpp$', r'#include', r'using\s+namespace', r'int\s+main', r'class\s+\w+\s*\{'],
    "c": [r'\.c$', r'#include', r'int\s+main', r'void\s+\w+\s*\(', r'struct\s+\w+\s*\{'],
    "html": [r'\.html$', r'\<\!DOCTYPE', r'\<html', r'\<head', r'\<body'],
    "css": [r'\.css$', r'\w+\s*\{', r'@media', r'@import', r'@keyframes'],
    "sql": [r'\.sql$', r'SELECT', r'INSERT', r'UPDATE', r'DELETE', r'CREATE\s+TABLE']
}

# Language-specific comment patterns for metrics
COMMENT_PATTERNS = {
    "python": r'(#[^\n]*|"""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\')',
    "javascript": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "typescript": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "java": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "go": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "c#": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "php": r'(//[^\n]*|/\*[\s\S]*?\*/|#[^\n]*)',
    "ruby": r'(#[^\n]*|=begin[\s\S]*?=end)',
    "c++": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "c": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "swift": r'(//[^\n]*|/\*[\s\S]*?\*/)',
    "kotlin": r'(//[^\n]*|/\*[\s\S]*?\*/)'
}

# Language-specific complexity patterns
COMPLEXITY_PATTERNS = {
    "python": r'(if|for|while|def|class|with|try|except)',
    "javascript": r'(if|for|while|function|class|try|catch|switch)',
    "typescript": r'(if|for|while|function|class|try|catch|switch|interface)',
    "java": r'(if|for|while|switch|case|try|catch|class|interface)',
    "go": r'(if|for|switch|func|struct|interface)',
    "c#": r'(if|for|while|switch|case|try|catch|class|interface)',
    "php": r'(if|for|while|switch|case|try|catch|class|interface|function)',
    "ruby": r'(if|for|while|case|begin|rescue|class|module|def)',
    "c++": r'(if|for|while|switch|case|try|catch|class|struct)',
    "c": r'(if|for|while|switch|case)',
    "swift": r'(if|for|while|switch|case|try|catch|class|struct|enum)',
    "kotlin": r'(if|for|while|when|try|catch|class|interface|fun)'
}


class AgentState(TypedDict):
    code: str
    code_language: str
    code_filename: str
    retrieved_chunks: List[Dict[str, Any]]
    answer: str
    metrics: Optional[Dict[str, Any]]
    dependencies: Optional[Dict[str, Any]]
    error: Optional[str]
    target_language: Optional[str]


def setup_vertex_ai(credentials_path: str, project: str, location: str) -> None:
    """Configure Vertex AI with the provided credentials and settings"""
    if not os.path.exists(credentials_path):
        sys.exit(f"❌ Vertex AI credentials file not found: {credentials_path}")
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path
    litellm.vertex_project = project
    litellm.vertex_location = location
    logger.info(f"✅ Vertex AI configured: project={project}, location={location}")


def check_model_access(model_name: str):
    """Verify that the specified LLM is accessible"""
    try:
        _ = completion(
            model=model_name,
            messages=[{"role": "user", "content": "ping"}],
            max_tokens=5,
            temperature=0
        )
        logger.info(f"✅ Verified access to model: {model_name}")
    except Exception as e:
        sys.exit(f"❌ Model {model_name} not accessible: {e}")


def load_resources(index_path: str, metadata_path: str, model_name: str):
    """Load FAISS index, metadata, and embedding model"""
    logger.info(f"📦 Loading FAISS index from {index_path}")
    try:
        index = faiss.read_index(index_path)
        with open(metadata_path, encoding="utf-8") as f:
            data = json.load(f)
        metadatas = data["chunks"] if isinstance(data, dict) and "chunks" in data else data
        embedding_model = SentenceTransformer(model_name)
        logger.info(f"✅ Resources loaded: {index.ntotal} vectors")
        return index, metadatas, embedding_model
    except Exception as e:
        sys.exit(f"❌ Failed to load resources: {e}")


def detect_language(code: str, filename: str = "") -> str:
    """Detect the programming language of the code"""
    if filename:
        for lang, patterns in LANGUAGE_PATTERNS.items():
            for pattern in patterns:
                if pattern.startswith(r'\.') and re.search(pattern, filename, re.IGNORECASE):
                    return lang
    
    scores = {lang: sum(bool(re.findall(p, code, re.IGNORECASE | re.MULTILINE)) 
                        for p in patterns if not p.startswith(r'\.')) 
              for lang, patterns in LANGUAGE_PATTERNS.items()}
    
    best_lang, score = max(scores.items(), key=lambda x: x[1], default=("unknown", 0))
    return best_lang if score > 0 else "unknown"


def get_cache_key(code: str) -> str:
    """Generate a cache key for the code"""
    return hashlib.md5(code.encode('utf-8')).hexdigest()


def mmr_search(
    query: str,
    code_language: str,
    index,
    metadatas,
    embedding_model,
    top_k=10,
    lambda_param=0.5
):
    """Maximum Marginal Relevance search to balance relevance with diversity"""
    language_query = f"recommendations for {code_language} code best practices"
    combined_query = f"{query} {language_query}"
    query_vec = embedding_model.encode(combined_query).astype("float32")

    # Make sure query_vec is properly shaped for FAISS
    query_vec = query_vec.reshape(1, -1)

    # Initial search to get candidate pool
    distances, indices = index.search(query_vec, top_k * 3)

    # Flatten the results since search returns 2D arrays
    distances = distances.flatten()
    indices = indices.flatten()

    # Filter valid indices and prepare for MMR
    candidate_ids = [idx for idx in indices if 0 <= idx < len(metadatas)]
    if not candidate_ids:
        return []

    # Get embeddings for candidates
    candidate_texts = [metadatas[idx]["text"] for idx in candidate_ids]
    candidate_embeddings = np.vstack([
        embedding_model.encode(text).astype("float32") for text in candidate_texts
    ])

    # Reshape query_vec for dot product
    query_vec = query_vec.flatten()

    # MMR algorithm
    selected_indices = []
    remaining_indices = list(range(len(candidate_ids)))

    for _ in range(min(top_k, len(candidate_ids))):
        if not remaining_indices:
            break

        # Calculate MMR scores
        mmr_scores = []
        for i in remaining_indices:
            # Calculate relevance (similarity to query)
            relevance = np.dot(candidate_embeddings[i], query_vec) / (
                np.linalg.norm(candidate_embeddings[i]) * np.linalg.norm(query_vec)
            )

            # Calculate diversity (distance from already selected)
            diversity = 1.0
            if selected_indices:
                similarities = [
                    np.dot(candidate_embeddings[i], candidate_embeddings[j]) / (
                        np.linalg.norm(candidate_embeddings[i]) * np.linalg.norm(candidate_embeddings[j])
                    )
                    for j in selected_indices
                ]
                diversity = 1 - max(similarities) if similarities else 1.0  # ✅ FIXED LINE

            # Combined MMR score
            mmr_score = lambda_param * relevance + (1 - lambda_param) * diversity
            mmr_scores.append((i, mmr_score))

        # Select the highest MMR score
        next_idx, _ = max(mmr_scores, key=lambda x: x[1])
        selected_indices.append(next_idx)
        remaining_indices.remove(next_idx)

    # Build results
    results = []
    for idx in selected_indices:
        original_idx = candidate_ids[idx]
        chunk = metadatas[original_idx]

        # Find the distance for this index
        distance_idx = np.where(indices == original_idx)[0]
        distance = distances[distance_idx[0]] if len(distance_idx) > 0 else 1.0

        results.append({
            "text": chunk["text"],
            "section": chunk.get("section", "Unknown"),
            "score": 1.0 / (1.0 + float(distance)),
            "keywords": chunk.get("keywords", [])
        })

    return results


def process_large_code(code: str, max_chunk_size: int = MAX_CHUNK_SIZE) -> List[str]:
    """Split large code files into manageable chunks for processing"""
    if len(code) <= max_chunk_size:
        return [code]
    
    # Try to split at logical boundaries
    lines = code.splitlines(True)  # Keep line endings
    chunks = []
    current_chunk = ""
    
    for line in lines:
        if len(current_chunk) + len(line) > max_chunk_size:
            # If adding this line would exceed max size, start a new chunk
            if current_chunk:
                chunks.append(current_chunk)
                current_chunk = ""
        
        current_chunk += line
        
        # Check if we're at a logical boundary (class/function definition, etc.)
        if re.match(r'^\s*$', line) and len(current_chunk) > max_chunk_size * 0.5:
            chunks.append(current_chunk)
            current_chunk = ""
    
    if current_chunk:
        chunks.append(current_chunk)
    
    return chunks


def analyze_code_metrics(code: str, language: str) -> Dict[str, Any]:
    """Calculate basic code quality metrics"""
    metrics = {
        "line_count": len(code.splitlines()),
        "char_count": len(code),
        "avg_line_length": round(len(code) / max(1, len(code.splitlines())), 2),
        "comment_ratio": 0,
        "complexity_estimate": 0
    }
    
    # Language-specific comment detection
    if language in COMMENT_PATTERNS:
        comments = re.findall(COMMENT_PATTERNS[language], code)
        comment_chars = sum(len(c) for c in comments)
        metrics["comment_ratio"] = round(comment_chars / max(1, len(code)), 3)
    
        # Simple complexity estimate based on control structures
    if language in COMPLEXITY_PATTERNS:
        control_structures = re.findall(COMPLEXITY_PATTERNS[language], code)
        metrics["complexity_estimate"] = len(control_structures)
    
    # Add cyclomatic complexity estimate
    if language in ["python", "javascript", "java", "c#", "c++", "c"]:
        # Count decision points (branches) for cyclomatic complexity
        decision_points = 0
        
        # Common decision patterns across languages
        decision_patterns = [
            r'\bif\b', r'\belse\s+if\b', r'\bswitch\b', r'\bcase\b',
            r'\bfor\b', r'\bwhile\b', r'\bdo\b', r'\bcatch\b'
        ]
        
        # Language-specific patterns
        if language == "python":
            decision_patterns.extend([r'\belif\b', r'\bexcept\b'])
        elif language in ["javascript", "typescript"]:
            decision_patterns.extend([r'\b\?\b', r'\?\.\b', r'\?\?'])  # Ternary and optional chaining
        elif language == "java":
            decision_patterns.extend([r'\b\?\b', r'&&', r'\|\|'])  # Ternary and logical operators
        
        for pattern in decision_patterns:
            decision_points += len(re.findall(pattern, code))
        
        # Cyclomatic complexity = E - N + 2P where:
        # E = edges, N = nodes, P = connected components (usually 1)
        # Simplified as: decision points + 1
        metrics["cyclomatic_complexity"] = decision_points + 1
    
    return metrics

def analyze_dependencies(code: str, language: str) -> Dict[str, Any]:
    """Extract and analyze dependencies from code"""
    dependencies = []
    
    if language == "python":
        # Extract import statements
        import_patterns = [
            r'import\s+(\w+)',
            r'from\s+(\w+)\s+import',
            r'import\s+(\w+)\s+as\s+\w+'
        ]
        
        for pattern in import_patterns:
            dependencies.extend(re.findall(pattern, code))
            
    elif language in ["javascript", "typescript"]:
        # Extract npm dependencies
        import_patterns = [
            r'import.*from\s+[\'"](.+?)[\'"]',
            r'require\([\'"](.+?)[\'"]\)'
        ]
        
        for pattern in import_patterns:
            dependencies.extend(re.findall(pattern, code))
        
    elif language == "java":
        # Extract Java imports
        dependencies.extend(re.findall(r'import\s+([\w\.]+);', code))
        
    elif language == "go":
        # Extract Go imports
        imports = re.findall(r'import\s+\(\s*(.*?)\s*\)', code, re.DOTALL)
        if imports:
            for imp_block in imports:
                dependencies.extend(re.findall(r'[\'"](.+?)[\'"]', imp_block))
        dependencies.extend(re.findall(r'import\s+[\'"](.+?)[\'"]', code))
        
    # Add more language-specific dependency extraction
        
    return {
        "dependencies": list(set(dependencies)),
        "count": len(set(dependencies))
    }


def collect_feedback(code_hash: str, feedback: str, rating: int) -> None:
    """Store user feedback for future improvements"""
    feedback_file = "user_feedback.jsonl"
    feedback_entry = {
        "timestamp": datetime.now().isoformat(),
        "code_hash": code_hash,
        "rating": rating,
        "feedback": feedback
    }
    
    with open(feedback_file, "a") as f:
        f.write(json.dumps(feedback_entry) + "\n")
    
    logger.info(f"Feedback collected for code {code_hash[:8]}, rating: {rating}")


def translate_recommendations(recommendations: str, target_language: str) -> str:
    """
    Translate recommendations to the target language.
    Keeps code snippets and technical terms in English.
    """
    if target_language.lower() == "english":
        return recommendations

    prompt = f"""Translate the following code recommendations to {target_language}. 
Keep code snippets and technical terms in English.

Original recommendations:
{recommendations}

{target_language} translation:"""

    try:
        response = litellm.completion(
            model=DEFAULT_LLM,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1500,
            temperature=0.1
        )

        # Log full raw response for debugging
        logger.debug(f"safe_completion raw response: {response}")

        choices = response.get("choices", [])
        if not choices:
            logger.error(f"Translation failed: no choices returned. Full response: {response}")
            return "⚠️ Translation failed: no choices returned from LLM."

        message = choices[0].get("message", {})
        content = message.get("content", None)

        if not content:
            logger.error(f"Translation failed: no content in response. Full response: {response}")
            return "⚠️ Translation failed: LLM returned no content."

        return content.strip()

    except Exception as e:
        logger.error(f"Translation error: {e}")
        return f"⚠️ Translation failed due to an error: {e}"

def retrieve_node(state: AgentState) -> AgentState:
    """Retrieve relevant chunks from the knowledge base"""
    logger.debug(f"mmr_search function defined at: {mmr_search.__code__.co_filename}:{mmr_search.__code__.co_firstlineno}")
    
    code_sample = state["code"][:1000]  # Currently unused, consider passing if needed
    
    language = state["code_language"]
    query = f"recommendations for {language} code best practices regarding performance, efficiency, and environmental impact"
    logger.debug(f"Retrieval query: {query}")
    
    try:
        retrieved = mmr_search(query, language, index, metadatas, embedding_model, top_k=7)
        logger.debug(f"Retrieved {len(retrieved)} chunks from mmr_search")
        # Filter by score and limit results
        filtered = [c for c in retrieved if c.get("score", 0) > 0.3][:5]
        logger.debug(f"Filtered to {len(filtered)} chunks with score > 0.3")
        state["retrieved_chunks"] = filtered
        
        # Add code metrics
        state["metrics"] = analyze_code_metrics(state["code"], language)
        
        # Add dependency analysis
        state["dependencies"] = analyze_dependencies(state["code"], language)
        
    except Exception as e:
        state["error"] = f"Error during retrieval: {str(e)}"
        logger.error(f"Retrieval error: {e}")
    
    return state

def generate_node(state: AgentState) -> AgentState:
    """Generate recommendations (streaming) based on retrieved chunks."""
    if state.get("error"):
        state["answer"] = f"An error occurred: {state['error']}"
        return state
        
    if not state["retrieved_chunks"]:
        state["answer"] = "No relevant recommendations found for your code."
        return state

    context = "\n\n".join(
        f"[{i+1}] [{c['section']}] {c['text']}" 
        for i, c in enumerate(state["retrieved_chunks"])
    )
    language, filename = state["code_language"], state["code_filename"]

    # Metrics & dependencies
    metrics_info = ""
    if state.get("metrics"):
        metrics_info = f"""
Code metrics:
- Lines of code: {state['metrics']['line_count']}
- Comment ratio: {state['metrics']['comment_ratio']}
- Complexity estimate: {state['metrics']['complexity_estimate']}
"""
        if "cyclomatic_complexity" in state["metrics"]:
            metrics_info += f"- Cyclomatic complexity: {state['metrics']['cyclomatic_complexity']}\n"

    dependencies_info = ""
    if state.get("dependencies") and state["dependencies"]["count"] > 0:
        dependencies_info = f"""
Dependencies ({state['dependencies']['count']}):
{', '.join(state['dependencies']['dependencies'][:10])}
"""
        if len(state['dependencies']['dependencies']) > 10:
            dependencies_info += f"... and {len(state['dependencies']['dependencies']) - 10} more"

    prompt = (
     f"You are an expert {language} code reviewer.\n"
    f"Your goal is to assess whether the following code respects the given best practice recommendations "
    f"for performance, efficiency, and environmental impact.\n\n"
    f"Best practice recommendations:\n{context}\n\n"
    f"Code metrics:\n{metrics_info}\n"
    f"Dependencies:\n{dependencies_info}\n\n"
    f"The user's code is:\n```{language}\n{state['code']}\n```\n\n"
    f"Task:\n"
    f"- Check each recommendation.\n"
    f"- If it is violated, explain why and propose a specific fix grounded in the recommendation.\n"
    f"- Do NOT list recommendations that are already respected.\n"
    f"- If ALL recommendations are respected, just say: "
    f"✅ All best practice recommendations are respected. No changes needed.\n\n"
    f"Format your response in Markdown, listing only the violated recommendations (if any) and fixes."
)

    try:
        state["answer"] = ""
        for chunk in litellm.completion(
            model=DEFAULT_LLM,
            messages=[
                {"role": "system", "content": f"Expert {language} reviewer focusing on best practices"},
                {"role": "user", "content": prompt}
            ],
            max_tokens=4000,
            temperature=0.2,
            top_p=0.9,
            stream=True
        ):
            logger.debug(f"Chunk received: {chunk}")
            if hasattr(chunk, 'choices') and chunk.choices:
                delta = getattr(chunk.choices[0], 'delta', None)
                if delta and getattr(delta, 'content', None):
                    content = delta.content
                    if isinstance(content, str) and content.strip() != "":
                        state["answer"] += content

        # Translate if needed
        if state.get("target_language") and state["target_language"].lower() != "english":
            state["answer"] = translate_recommendations(state["answer"], state["target_language"])

    except Exception as e:
        state["error"] = f"Error during generation: {str(e)}"
        state["answer"] = f"Failed to generate recommendations: {str(e)}"
        logger.error(f"Generation error: {e}")

    return state

def parallel_process_chunks(code_chunks: List[str], language: str, filename: str) -> str:
    """Process multiple code chunks in parallel and combine results"""
    results = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(code_chunks), 5)) as executor:
        future_to_chunk = {
            executor.submit(process_single_chunk, chunk, language, f"{filename} (part {i+1}/{len(code_chunks)})"): i 
            for i, chunk in enumerate(code_chunks)
        }
        
        for future in concurrent.futures.as_completed(future_to_chunk):
            chunk_idx = future_to_chunk[future]
            try:
                result = future.result()
                results.append((chunk_idx, result))
            except Exception as e:
                logger.error(f"Error processing chunk {chunk_idx}: {e}")
                results.append((chunk_idx, f"Error processing this section: {str(e)}"))
    
    # Sort results by chunk index and combine
    sorted_results = [res for _, res in sorted(results, key=lambda x: x[0])]
    combined = "\n\n## ===== Next Section =====\n\n".join(sorted_results)
    
    return combined


def process_single_chunk(code_chunk: str, language: str, chunk_name: str) -> str:
    """Process a single code chunk and return recommendations"""
    initial_state = {
        "code": code_chunk,
        "code_language": language,
        "code_filename": chunk_name,
        "retrieved_chunks": [],
        "answer": "",
        "metrics": None,
        "dependencies": None,
        "error": None
    }
    
    # Use the agent to process this chunk
    final_state = agent.invoke(initial_state)
    return final_state["answer"]


def benchmark_performance():
    """Benchmark system performance with sample code files"""
    sample_files = [f for f in os.listdir("benchmark_samples") if os.path.isfile(os.path.join("benchmark_samples", f))]
    results = []
    
    for file in sample_files:
        filepath = os.path.join("benchmark_samples", file)
        with open(filepath, "r") as f:
            code = f.read()
        
        language = detect_language(code, file)
        
        start_time = time.time()
        initial_state = {
            "code": code,
            "code_language": language,
            "code_filename": file,
            "retrieved_chunks": [],
            "answer": "",
            "metrics": None,
            "dependencies": None,
            "error": None
        }
        
        try:
            retrieve_start = time.time()
            state_after_retrieve = retrieve_node(initial_state)
            retrieve_time = time.time() - retrieve_start
            
            generate_start = time.time()
            final_state = generate_node(state_after_retrieve)
            generate_time = time.time() - generate_start
            
            total_time = time.time() - start_time
            
            results.append({
                "file": file,
                "language": language,
                "retrieve_time": retrieve_time,
                "generate_time": generate_time,
                "total_time": total_time,
                "chunks_retrieved": len(state_after_retrieve["retrieved_chunks"]),
                "success": True
            })
        except Exception as e:
            results.append({
                "file": file,
                "language": language,
                "error": str(e),
                "success": False
            })
    
    with open("benchmark_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    return results


def build_agent():
    """Build the agent workflow"""
    graph = StateGraph(AgentState)
    graph.add_node("retrieve", retrieve_node)
    graph.add_node("generate", generate_node)
    
    # Define the workflow
    graph.add_edge("retrieve", "generate")
    graph.add_edge("generate", END)
    
    # Set the entry point
    graph.set_entry_point("retrieve")
    
    return graph.compile()


def gradio_wrapper(user_file, code_text=None, language=None, target_language="English") -> Tuple[str, Dict[str, Any]]:
    """
    Process code from file or text input and return recommendations and metrics.
    Supports single files or .zip archives (reviews each file individually).
    """

    # Build the state
    if user_file:
        # Prepare full state from file (zip or not)
        state = prepare_state_from_input(
            user_file.name,
            language if language else "unknown",
            target_language
        )
    elif code_text:
        # Raw text input
        detected_language = detect_language(code_text, "code_snippet.txt")
        code_language = language if language else detected_language
        state = {
            "files": [("code_snippet.txt", code_text)],
            "code_language": code_language,
            "target_language": target_language
        }
    else:
        return "Please upload a file or paste code", None

    results = []
    combined_metrics = {"Code Metrics": {}, "Dependencies": {}}

    # Loop over each file
    for filename, code in state["files"]:
        if not code.strip():
            continue

        # Cache key per file
        cache_key = get_cache_key(code)
        if cache_key in RESPONSE_CACHE:
            cached_result = RESPONSE_CACHE[cache_key]
            if isinstance(cached_result, tuple):
                results.append(f"### 📄 **{filename}**\n\n{cached_result[0]}")
                continue

        # Handle large files by chunking
        code_chunks = process_large_code(code) if len(code) > MAX_CHUNK_SIZE else [code]

        if len(code_chunks) > 1:
            logger.info(f"Processing {filename} in {len(code_chunks)} chunks")
            response = parallel_process_chunks(code_chunks, state["code_language"], filename)
            metrics = analyze_code_metrics(code, state["code_language"])
            dependencies = analyze_dependencies(code, state["code_language"])
        else:
            initial_state: AgentState = {
                "code": code,
                "code_language": state["code_language"],
                "code_filename": filename,
                "retrieved_chunks": [],
                "answer": "",
                "metrics": None,
                "dependencies": None,
                "error": None,
                "target_language": state["target_language"]
            }

            final_state = agent.invoke(initial_state)
            response = final_state["answer"]
            metrics = final_state.get("metrics", {})
            dependencies = final_state.get("dependencies", {})

        # Collect results
        results.append(f"### 📄 **{filename}**\n\n{response}")

        combined_metrics["Code Metrics"][filename] = metrics
        combined_metrics["Dependencies"][filename] = dependencies.get("dependencies", [])

        # Cache the result
        RESPONSE_CACHE[cache_key] = (response, {filename: {"metrics": metrics, "dependencies": dependencies}})

    # Manage cache size
    if len(RESPONSE_CACHE) > MAX_CACHE_SIZE:
        oldest_keys = list(RESPONSE_CACHE.keys())[:(len(RESPONSE_CACHE) - MAX_CACHE_SIZE)]
        for key in oldest_keys:
            del RESPONSE_CACHE[key]

    # Combine all per-file responses
    final_response = "\n\n---\n\n".join(results)

    return final_response, combined_metrics




def create_interface():
    """Create the Gradio interface"""
    with gr.Blocks(title="Code Recommendation Checker") as iface:
        gr.Markdown("# Code Recommendation Checker")
        gr.Markdown("Upload a code file or paste code to get recommendations for improving performance, efficiency, and environmental impact.")
        
        with gr.Row():
            with gr.Column(scale=2):
                file_input = gr.File(label="Upload your code file")
                code_input = gr.Textbox(label="Or paste your code here", lines=10)
                
                with gr.Row():
                    language_dropdown = gr.Dropdown(
                        choices=list(LANGUAGE_PATTERNS.keys()), 
                        label="Language (auto-detected if not specified)"
                    )
                    target_language = gr.Dropdown(
                        choices=["English", "Spanish", "French", "German", "Chinese", "Japanese", "Russian", "Portuguese", "Arabic"],
                        label="Output Language",
                        value="English"
                    )
                
                with gr.Row():
                    submit_btn = gr.Button("Analyze Code", variant="primary")
                    clear_btn = gr.Button("Clear")
            
            with gr.Column(scale=3):
                output = gr.Markdown(label="Recommendations")
                metrics_output = gr.JSON(label="Code Metrics")
                
                with gr.Row():
                    feedback_text = gr.Textbox(label="Provide feedback to improve the system", lines=2)
                    feedback_rating = gr.Slider(minimum=1, maximum=5, step=1, label="Rate the recommendations", value=3)
                    feedback_btn = gr.Button("Submit Feedback")
        
        def submit_user_feedback(file, code_text, feedback, rating):
            """Handle user feedback submission"""
            if file:
                with open(file.name, encoding="utf-8") as f:
                    code = f.read()
            elif code_text:
                code = code_text
            else:
                return "No code to provide feedback on"
            
            code_hash = get_cache_key(code)
            collect_feedback(code_hash, feedback, rating)
            return "Thank you for your feedback!"
        
        def clear_inputs():
            """Clear all input fields"""
            return None, "", None, "", None
        
        # Connect the interface components
        submit_btn.click(
            fn=gradio_wrapper, 
            inputs=[file_input, code_input, language_dropdown, target_language], 
            outputs=[output, metrics_output]
        )
        
        feedback_btn.click(
            fn=submit_user_feedback,
            inputs=[file_input, code_input, feedback_text, feedback_rating],
            outputs=gr.Textbox()
        )
        
        clear_btn.click(
            fn=clear_inputs,
            inputs=None,
            outputs=[file_input, code_input, language_dropdown, output, metrics_output]
        )
        
    return iface


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Code Recommendation Checker")
    parser.add_argument('--port', type=int, default=7860, help="Port to run the Gradio server on")
    parser.add_argument('--share', action='store_true', help="Create a shareable link")
    parser.add_argument('--index', default=DEFAULT_INDEX_PATH, help="Path to FAISS index file")
    parser.add_argument('--metadata', default=DEFAULT_METADATA_PATH, help="Path to metadata JSON file")
    parser.add_argument('--credentials', default=DEFAULT_CREDENTIALS_PATH, help="Path to Vertex AI credentials")
    parser.add_argument('--llm', default=DEFAULT_LLM, help="LLM model to use")
    parser.add_argument('--vertex_project', default=DEFAULT_VERTEX_PROJECT, help="Vertex AI project ID")
    parser.add_argument('--vertex_location', default=DEFAULT_VERTEX_LOCATION, help="Vertex AI location")
    parser.add_argument('--benchmark', action='store_true', help="Run benchmarks on sample files")
    args = parser.parse_args()

    # Set the LLM model
    llm_model = args.llm

    # Setup Vertex AI
    setup_vertex_ai(args.credentials, args.vertex_project, args.vertex_location)
    check_model_access(llm_model)

    # Load resources
    global index, metadatas, embedding_model
    index, metadatas, embedding_model = load_resources(args.index, args.metadata, DEFAULT_MODEL)

    # Build the agent
    global agent
    agent = build_agent()

    # Run benchmarks if requested
    if args.benchmark:
        logger.info("Running benchmarks...")
        results = benchmark_performance()
        logger.info(f"Benchmark complete. Results saved to benchmark_results.json")
        return 0

    # Launch the interface
    logger.info(f"Starting Gradio interface on port {args.port}")
    iface = create_interface()
    iface.launch(server_port=args.port, share=args.share)
    return 0


if __name__ == "__main__":
    exit(main())
