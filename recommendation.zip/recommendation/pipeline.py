from clean import clean_docx
from build_knowledge_base import build_knowledge_chunks
from build_vector_store import build_vector_store
from query_knowledge_base import query_knowledge_base

def main():
    # 1. Clean
    data = clean_docx("recommendation.docx")
    print("Step 1: Document cleaned.")

    # 2. Build knowledge chunks
    chunks = build_knowledge_chunks(data)
    print(f"Step 2: Built {len(chunks)} knowledge chunks.")

    # 3. Build vector store
    index, metadatas = build_vector_store(chunks)
    print("Step 3: Vector store built.")

    # 4. Query example (optional)
    user_query = "What are the cache recommendations?"
    results = query_knowledge_base(index, metadatas, user_query)
    print(f"Step 4: Query results for '{user_query}':")
    for i, res in enumerate(results):
        print(f"{i+1}. Section: {res['section']}")
        print(f"   Text: {res['text']}\n")

   