import zipfile
import os
import tempfile

def prepare_state_from_input(uploaded_path: str, code_language: str, target_language="english") -> dict:
    """
    Prépare les états RAG pour chaque fichier
    """
    state = {
        "code_language": code_language,
        "target_language": target_language
    }

    if uploaded_path.endswith(".zip"):
        files = []
        with tempfile.TemporaryDirectory() as tmpdir:
            with zipfile.ZipFile(uploaded_path, 'r') as zip_ref:
                zip_ref.extractall(tmpdir)

            for root, dirs, filelist in os.walk(tmpdir):
                for file in filelist:
                    if file.endswith((".py", ".js", ".java", ".cpp", ".c", ".ts", ".rb", ".php", ".go", ".rs", ".cs", ".swift", ".kt", ".html", ".css", ".sql")):
                        filepath = os.path.join(root, file)
                        try:
                            with open(filepath, 'r', encoding='utf-8') as f:
                                code = f.read()
                                if code.strip():
                                    relpath = os.path.relpath(filepath, tmpdir)
                                    files.append( (relpath, code) )
                        except Exception:
                            pass

        if not files:
            state["files"] = [("No supported code files found in the ZIP.", "")]
        else:
            state["files"] = files

    else:
        with open(uploaded_path, 'r', encoding='utf-8') as f:
            code = f.read()
            state["files"] = [(os.path.basename(uploaded_path), code)]

    return state

